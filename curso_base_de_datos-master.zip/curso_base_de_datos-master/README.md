##### Ejemplos vistos a lo largo del __curso profesional de base de datos__.

Link del [curso_db]

[curso_db]: <https://codigofacilito.com/cursos/base-datos-profesional>
